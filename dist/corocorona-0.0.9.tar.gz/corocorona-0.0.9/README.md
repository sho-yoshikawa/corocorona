# corocorona

display Total number of corona infections

## Getting Started

test package for me!

### Requirements

```
python >= 3.9
```
Nothing more

### Installing

```
pip install corocorona
```

### How to use

```
from printCorona import corona
printCorona()
```

### Display

[東京都]
累計感染者数： 3,343,691
(最終更新日：2022-11-11)

[埼玉県]
累計感染者数： 1,275,759
(最終更新日：2022-11-11)

## Authors

* **Sho Yoshikawa**
