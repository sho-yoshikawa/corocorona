# corocorona

display Total number of corona infections

## Getting Started

test package for me!

### Requirements

```
python >= 3.9
```
Nothing more

### Installing

```
pip install corocorona
```

### How to use

```
from corona import corocorona
printCorona()
```

## Authors

* **Sho Yoshikawa**
